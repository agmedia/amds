<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Heading
$_['heading_title']    = 'Mapa stranice (site map)';

// Text
$_['text_special']     = 'Akcije/posebne ponude';
$_['text_account']     = 'Moj korisnički račun';
$_['text_edit']        = 'Detalji korisničkog računa';
$_['text_password']    = 'Lozinka';
$_['text_address']     = 'Adresar/imenik';
$_['text_history']     = 'Povijest narudžbi';
$_['text_download']    = 'Preuzimanja (download-i)';
$_['text_cart']        = 'Košarica';
$_['text_checkout']    = 'Naplata';
$_['text_search']      = 'Traži';
$_['text_information'] = 'Informacije';
$_['text_contact']     = 'Kontaktirajte nas';
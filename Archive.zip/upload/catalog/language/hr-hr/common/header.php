<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_home']          = 'Naslovna';
$_['text_wishlist']      = 'Lista želja (%s)';
$_['text_shopping_cart'] = 'Košarica';
$_['text_category']      = 'Sve kategorije';
$_['text_account']       = 'Moj račun';
$_['text_register']      = 'Registracija';
$_['text_login']         = 'Prijava';
$_['text_order']         = 'Povijest narudžbi';
$_['text_transaction']   = 'Transakcije';
$_['text_download']      = 'Preuzimanja (download-i)';
$_['text_logout']        = 'Odjava';
$_['text_checkout']      = 'Naplata';
$_['text_search']        = 'Traži';
$_['text_all']           = 'Prikaži sve';
<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_information']  = 'Informacije';
$_['text_service']      = 'Služba za korisnike';
$_['text_extra']        = 'Dodaci';
$_['text_contact']      = 'Kontaktirajte nas';
$_['text_return']       = 'Internetsko rješavanje sporova ';
$_['text_sitemap']      = 'Mapa site-a';
$_['text_manufacturer'] = 'Brandovi';
$_['text_voucher']      = 'Poklon bonovi';
$_['text_affiliate']    = 'Partneri';
$_['text_special']      = 'Akcije';
$_['text_account']      = 'Korisnički račun';
$_['text_order']        = 'Povijest narudžbi';
$_['text_wishlist']     = 'Lista želja';
$_['text_newsletter']   = 'Newsletter';
//$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
$_['text_powered']      = '<a href="https://www.agmedia.hr" target="agmedia">AG media</a><br /> %s &copy; %s';
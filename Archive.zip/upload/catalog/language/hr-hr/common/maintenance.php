<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Heading
$_['heading_title']    = 'Održavanje';

// Text
$_['text_maintenance'] = 'Održavanje';
$_['text_message']     = '<h1 style="text-align:center;">Trenutno se vrši održavanje web shopa. <br/>Web shop bit će aktivan u najkraćem mogućem roku.</h1>';
<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_items']     = '%s artikal(a) - %s';
$_['text_empty']     = 'Vaša košarica je prazna!!';
$_['text_cart']      = 'Košarica';
$_['text_checkout']  = 'Naplata';
$_['text_recurring'] = 'Profil ponavljajuće naplate';
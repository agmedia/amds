<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Heading
$_['heading_title']        = 'Hvala vam na povjerenju!';

// Text
$_['text_basket']          = 'Košarica';
$_['text_checkout']        = 'Naplata';
$_['text_success']         = 'Uspješno';
$_['text_customer']        = '<p>Vaša narudžba je uspješno zaprimljena i obrađena!</p><p>Možete pogledati pregled Vaših narudžbi na stranici <a href="%s">moj korisnički račun</a> ili kliknuvši na <a href="%s">povijest narudžbi</a>.</p><p style="display:none">Ako Vaša narudžba sadrži artikle za download, možete otići na <a href="%s">download</a> stranicu da ih pogledate i preuzmete.</p><p>Molimo Vas da ukoliko imate nekih pitanja ista uputite <a href="%s">vlasniku web trgovine</a>.</p><p>Zahvaljujemo se što ste kupovali online kod nas!</p>';
$_['text_guest']           = '<p>Vaša narudžba je uspješno zaprimljena i obrađena!</p><p>Molimo Vas da ukoliko imate nekih pitanja ista uputite <a href="%s">vlasniku web trgovine</a>.</p><p>Zahvaljujemo se što ste kupovali online kod nas!</p>';

$_['text_tnx']           ='Hvala vam na povjerenju!';
$_['text_pouzece']           = '<p>Uredno smo zaprimili Vašu narudžbu broj  %s</p><p>Naš tim u webshopu će je obraditi u najbržem mogućem roku.</p><p>Podsjećamo Vas da ćete plaćanje obaviti kod kurira naše dostavne službe pri preuzimanju paketa, te Vas molimo ukoliko ste u mogućnosti da pripremite točan iznos novca za Vašu narudžbu.</p>';

$_['text_bank']           = '<p>Uredno smo zaprimili Vašu narudžbu broj %s i zahvaljujemo Vam.</p><p>Molimo vas da izvršite uplatu po sljedećim uputama za plaćanje.</p><p> Rok za uplatu je maksimalno 48h tijekom koga robu koju ste naručili držimo rezerviranu za vas.</p><p> Ukoliko u tom roku ne zaprimimo uplatu, nažalost moramo poništiti ovu narudžbu.</p><p>MOLIMO IZVRŠITE UPLATU U IZNOSU OD %s <br>
IBAN RAČUN: HR4424070001100582698<br>
MODEL: 05 POZIV NA BROJ: %s</p>

<p>ILI JEDNOSTAVNO POSKENIRAJTE 2D BARKOD</p>';

$_['text_wspay']           = '<p>Uredno smo zaprimili Vašu narudžbu kao i uplatu za narudžbu broj  %s</p><p>Naš tim u webshopu će je obraditi u najbržem mogućem roku.</p>';




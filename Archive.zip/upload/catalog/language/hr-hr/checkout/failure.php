<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Heading
$_['heading_title'] = 'Neuspjelo plaćanje!';

// Text
$_['text_basket']   = 'Košarica';
$_['text_checkout'] = 'Naplata';
$_['text_failure']  = 'Neuspjelo plaćanje';
$_['text_message']  = '<p>Nastao je problem kod procesiranja Vašeg plaćanja te narudžba nije završena.</p>

<p>Mogući razlozii su:</p>
<ul>
  <li>Nedovoljno sredstava na računu</li>
  <li>Neuspjela provjera/verifikacija</li>
</ul>

<p>Molim pokušajte ponovo završiti narudžbu koristeći drgi način plaćanja.</p>

<p>Ako nakon toga, problem i dalje postoji, <a href="%s">kontaktirajte nas</a> s detaljima Vaše narudžbe koju pokušavate napraviti..</p>
';

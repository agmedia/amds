<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_refine']       = 'Poboljšana pretraga';
$_['text_product']      = 'Artikli';
$_['text_error']        = 'Kategorija nije pronađena!';
$_['text_empty']        = 'Nema artikala za prikaz u ovoj kategoriji.';
$_['text_quantity']     = 'Kol:';
$_['text_manufacturer'] = 'Proizvođač:';
$_['text_model']        = 'Model:';
$_['text_points']       = 'Nagradni bodovi:';
$_['text_price']        = 'Cijena:';
$_['text_tax']          = 'Bez poreza:';
$_['text_compare']      = 'Usporedi artikle (%s)';
$_['text_sort']         = 'Sortiraj po:';
$_['text_default']      = 'Sortiraj po:';
$_['text_name_asc']     = 'Naziv (A -&gt; Z)';
$_['text_name_desc']    = 'Naziv (Z -&gt; A)';
$_['text_price_asc']    = 'Cijena (niža -&gt; viša)';
$_['text_price_desc']   = 'Cijena (viša -&gt; niža)';
$_['text_rating_asc']   = 'Ocjena (najniža)';
$_['text_rating_desc']  = 'Ocjena (najviša)';
$_['text_model_asc']    = 'Model (A -&gt; Z)';
$_['text_model_desc']   = 'Model (Z -&gt; A)';
$_['text_limit']        = 'Prikaži:';
$_['text_pagination_limit']       = 'Ukupno %d ';
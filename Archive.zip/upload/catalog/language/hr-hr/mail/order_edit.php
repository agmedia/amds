<?php
// Text
$_['text_subject']      = '%s - Order Update %s';
$_['text_order_id']     = 'Narudžba broj:';
$_['text_date_added']   = 'Datum narudžbe::';
$_['text_order_status'] = 'Vaša narudžba ažurirana je na slijedeći status:';
$_['text_comment']      = 'Komentari uz Vašu narudžbu su:';
$_['text_link']         = 'Da biste pregledali Vašu narudžbu, kliknite na link ispod:';
$_['text_footer']       = 'Ako imate bilo kakvih dodatnih pitanja, molim odgovorite na ovaj e-mail.';
$_['text_update_order']         = 'Narudžba broj.:';
$_['text_update_date_added']    = 'Datum narudžbe:';
$_['text_update_order_status']  = 'Vaša narudžba ažurirana je na slijedeći status:';
$_['text_update_comment']       = 'Komentari uz Vašu narudžbu su:';
$_['text_update_link']          = 'Da biste pregledali Vašu narudžbu, kliknite na link ispod:';
$_['text_update_footer']        = 'Ako imate bilo kakvih dodatnih pitanja, molim odgovorite na ovaj e-mail.';
<?php
// Text
$_['text_subject']      = '%s - Narudžba  %s';
$_['text_received']     = 'Zaprimili ste narudžbu.';
$_['text_order_id']     = 'Narudžba broj:';
$_['text_date_added']   = 'Datum dodavanja:';
$_['text_order_status'] = 'Status narudžbe:';
$_['text_product']      = 'Proizvodi';
$_['text_total']        = 'Ukupno';
$_['text_comment']      = 'Komentari uz Vašu narudžbu su:';

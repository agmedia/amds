<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_subject']  = '%s - Zatraženo resetiranje lozinke';
$_['text_greeting'] = 'Nova lozinka zatražena je za %s korisnički račun.';
// $_['text_password'] = 'Vaša nova lozinka je:'; // postojalo u verziji OC 2.1.0.1
$_['text_change']   = 'Da biste resetirali Vašu lozinku kliknite na poveznicu (link) ispod:';
$_['text_ip']       = 'Ovaj zahtjev došao je s IP adrese: %s';

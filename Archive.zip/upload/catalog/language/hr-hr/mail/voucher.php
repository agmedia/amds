<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_subject']  = 'Poslan Vam je poklon bon sa %s';
$_['text_greeting'] = 'Čestitamo, primili ste poklon bon u vrijednosti %s';
$_['text_from']     = 'Ovaj poklon bon poslao Vam je %s';
$_['text_message']  = 'Uz poruku';
$_['text_redeem']   = 'Da biste preuzeli ovaj poklon bon i mogli s njim izvršiti kupnju, zapišite kod poklon bona koji je <b>%s</b> i zatim kliknite na link ispod i kupite artikl/artikle na koje želite iskoristiti ovaj poklon bon. Možete unijeti kod poklon bona na stranici košarice prije nego što kliknete na naplatu.';
$_['text_footer']   = 'Ako imate bilo kakvih dodatnih pitanja, molim odgovorite na ovaj e-mail.';
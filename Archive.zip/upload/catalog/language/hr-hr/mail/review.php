<?php
// Croatian   v.2.x.x     Datum: 01.10.2014		Author: Gigo (Igor Ilić - igor@iligsoft.hr)
// Text
$_['text_subject']	= '%s - recenzije artikla';
$_['text_waiting']	= 'Na čekanju imate novu recenziju artikla.';
$_['text_product']	= 'Artikl: %s';
$_['text_reviewer']	= 'Recenzent/ocjenjivač: %s';
$_['text_rating']	= 'Ocjena: %s';
$_['text_review']	= 'Tekst recenzije:';
<?php
// Version
$_['pqe_plus_version'] = '1.12.0';

// Configuration
$_['pqe_plus_extensions'] = array(
);
